import React from "react";
import Contact from "./components/Contact";

const App = () => (
  <div>
    <Contact />
  </div>
);

export default App;
import React from "react";
import "../styles/Contact.css";

const Contact = () => (
            <div className="App">
                <header className="App-header">

                    <h1 className="App-title">Contact Page</h1>

                    <p>

                        Contact the crew behind the build!

          </p>

                </header>

                <div>

                    <form>

                        <h2>Headquarters</h2>

                        <p>UNCC Center City Campus</p>
                        <p>320 E 9th St</p>
                        <p>Charlotte, NC 28202</p>

                    </form>

                </div>

            </div>
        );

export default Contact;